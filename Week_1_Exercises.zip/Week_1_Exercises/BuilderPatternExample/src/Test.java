public class Test
{
    public static void main(String[] args)
    {
        // Creating a basic Computer configuration
        Computer basicComp = new Computer.Builder("Intel i5", "8GB", "256GB SSD")
                .build();

        System.out.println("Basic Computer: " + basicComp);

        // Creating a high-end Computer configuration
        Computer gamingComp = new Computer.Builder("Intel i9", "16GB", "512GB SSD")
                .setGraphicsCard(true)
                .setWiFi(true)
                .build();

        System.out.println("Gaming Computer: " + gamingComp);
    }
}