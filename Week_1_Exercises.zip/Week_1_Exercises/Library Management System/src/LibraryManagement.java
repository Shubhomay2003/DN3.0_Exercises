public class LibraryManagement
{
    private Book[] books;
    private int count;

    public LibraryManagement(int capacity)
    {
        books = new Book[capacity];
        count = 0;
    }

    // Add a new book to the library
    public void addBook(Book book)
    {
        if (count >= books.length)
        {
            System.out.println("Library is full, cannot add more books.");
            return;
        }
        books[count++] = book;
    }

    // Linear search to find books by title
    public Book linearSearchByTitle(String t)
    {
        for (int i = 0; i < count; i++)
        {
            if (books[i].getTitle().equalsIgnoreCase(t))
            {
                return books[i];
            }
        }
        return null;
    }

    // Binary search to find books by title (assuming books array is sorted by title)
    public Book binarySearchByTitle(String title)
    {
        int l = 0;
        int r = count - 1;
        System.out.println(r);
        while (l <= r)
        {
            int mid = (l + r) / 2;
            int comp = books[mid].getTitle().compareToIgnoreCase(title);
            if (comp == 0)
            {
                return books[mid];
            }
            else if (comp < 0)
            {
                l = mid + 1;
            }
            else
            {
                r = mid - 1;
            }
        }
        return null;
    }

    // Display all books in the library
    public void displayBooks()
    {
        for (int i = 0; i < count; i++)
        {
            System.out.println(books[i]);
        }
    }
}
