
public class Main
{
    public static void main(String[] args)
    {
        LibraryManagement library = new LibraryManagement(10);

        // Adding books
        library.addBook(new Book("B001", "All the Light We Cannot See", "F. Anthony Doerr"));
        library.addBook(new Book("B002", "City of Bones", "Cassandra Clare"));
        library.addBook(new Book("B003", "Daughter of Smoke and Bone", "Laini Taylor"));
        library.addBook(new Book("B004", "The Catcher in the Rye", "J.D. Salinger"));
        library.addBook(new Book("B005", "The Hobbit", "J.R.R. Tolkien"));

        // Display all books
        System.out.println("All Books in the Library:");
        library.displayBooks();

        // Linear search for a book by title
        String searchTitle = "City of Bones";
        System.out.println("\nLinear Search for book titled '" + searchTitle + "':");
        Book foundBookLinear = library.linearSearchByTitle(searchTitle);
        if (foundBookLinear != null)
        {
            System.out.println("Book found: " + foundBookLinear);
        }
        else
        {
            System.out.println("Book not found.");
        }

        // Binary search for a book by title
        searchTitle = "The Hobbit";
        System.out.println("\nBinary Search for book titled '" + searchTitle + "':");
        Book foundBookBinary = library.binarySearchByTitle(searchTitle);
        if (foundBookBinary != null)
        {
            System.out.println("Book found: " + foundBookBinary);
        }
        else
        {
            System.out.println("Book not found.");
        }
    }
}