public class Test {
    public static void main(String[] args)
    {
        // Create the payment context
        PaymentContext paymentContext = new PaymentContext();

        // Use Credit Card Payment Strategy
        PaymentStrategy creditCardPayment = new CreditCardPayment("4231-5678-9876-5432", "Shubhomay Kundu Poddar");
        paymentContext.setPaymentStrategy(creditCardPayment);
        System.out.println("Executing payment via Credit Card:");
        paymentContext.executePayment(250.75);

        // Use PayPal Payment Strategy
        PaymentStrategy payPalPayment = new PayPalPayment("shubhomaykp@gmail.com");
        paymentContext.setPaymentStrategy(payPalPayment);
        System.out.println("\nExecuting payment via PayPal:");
        paymentContext.executePayment(120.99);
    }
}
