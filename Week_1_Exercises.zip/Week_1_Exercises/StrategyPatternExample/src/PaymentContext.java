public class PaymentContext
{
    private PaymentStrategy paymentStrat;

    public void setPaymentStrategy(PaymentStrategy paymentStrat)
    {
        this.paymentStrat = paymentStrat;
    }

    public void executePayment(double amt)
    {
        paymentStrat.pay(amt);
    }
}