public class CreditCardPayment implements PaymentStrategy
{
    private String cardNumber;
    private String cardHolderName;

    public CreditCardPayment(String cardNumber, String cardHolderName)
    {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
    }

    @Override
    public void pay(double amt)
    {
        System.out.println("Paying Rs. " + amt + " using Credit Card.");
    }
}