//Adaptee class 1
public class PhonepeGateway
{
    public void charge(double amount)
    {
        System.out.println("Charging Rs." + amount + " through PhonePe.");
    }
}