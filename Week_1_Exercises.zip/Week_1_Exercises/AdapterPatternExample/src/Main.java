
public class Main
{
    public static void main(String[] args)
    {
        // Create instances of the gateways
        PayPalGateway payPalGateway = new PayPalGateway();
        PhonepeGateway phonpeGateway = new PhonepeGateway();

        // Create adapter instances
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        PaymentProcessor phonepeAdapter = new PhonePeAdapter(phonpeGateway);

        // Process payments using the adapters
        System.out.println("Testing PayPal Adapter:");
        payPalAdapter.processPayment(120.0);

        System.out.println("\nTesting PhonePe Adapter:");
        phonepeAdapter.processPayment(150.0);
    }
}