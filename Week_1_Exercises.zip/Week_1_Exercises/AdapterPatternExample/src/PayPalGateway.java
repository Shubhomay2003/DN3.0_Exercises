//Adaptee class 2
public class PayPalGateway
{
    public void makePayment(double amount)
    {
        System.out.println("Processing payment of Rs." + amount + " through PayPal.");
    }
}