//Adapter class 1
public class PhonePeAdapter implements PaymentProcessor
{
    private PhonepeGateway phonpeGateway;

    public PhonePeAdapter(PhonepeGateway phonpeGateway)
    {
        this.phonpeGateway = phonpeGateway;
    }

    @Override
    public void processPayment(double amount)
    {
        phonpeGateway.charge(amount);
    }
}