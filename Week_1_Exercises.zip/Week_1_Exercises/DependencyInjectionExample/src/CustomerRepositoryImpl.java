public class CustomerRepositoryImpl implements CustomerRepository
{
    @Override
    public Customer findCustomerById(int id)
    {
        // Finding customer by ID
        //Since for example we will be dealing with one Student object so we return the object created
        return new Customer(id, "Shubhomay Kundu Poddar", "shubhomaykp@gmail.com");
    }
}
