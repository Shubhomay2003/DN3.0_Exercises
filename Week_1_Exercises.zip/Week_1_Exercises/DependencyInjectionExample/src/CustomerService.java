public class CustomerService
{
    private final CustomerRepository customerRepo;

    // Constructor Injection
    public CustomerService(CustomerRepository customerRepository)
    {
        this.customerRepo = customerRepository;
    }

    public Customer getCustomer(int id)
    {
        return customerRepo.findCustomerById(id);
    }
}

