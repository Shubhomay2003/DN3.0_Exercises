public class Test {
    public static void main(String[] args)
    {
        // Create the receiver
        Light bedroom = new Light();

        // Create concrete commands
        Command lightOn = new LightOnCommand(bedroom);
        Command lightOff = new LightOffCommand(bedroom);

        // Create the invoker
        RemoteControl remote = new RemoteControl();

        // Turn on the light
        remote.setCommand(lightOn);
        remote.pressButton();

        // Turn off the light
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}