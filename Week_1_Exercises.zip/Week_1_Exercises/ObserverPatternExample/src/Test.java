public class Test
{
    public static void main(String[] args)
    {
        // Create the stock market (subject)
        StockMarket stockMarket = new StockMarket();

        // Create observers
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        // Register observers
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Set stock prices and notify observers
        System.out.println("Setting stock price to Rs. 1000.00");
        stockMarket.setStockPrice(1000.00);

        System.out.println("\nSetting stock price to Rs. 1050.50");
        stockMarket.setStockPrice(1050.50);

        // Deregister an observer
        stockMarket.deregisterObserver(mobileApp);

        System.out.println("\nSetting stock price to Rs. 1100.75");
        stockMarket.setStockPrice(1100.75);
    }
}
