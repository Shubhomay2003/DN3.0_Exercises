
public class Main
{
    public static void main(String[] args)
    {
        Search searchOps = new Search(10);

        // Adding products
        searchOps.addProduct(new Product("P001", "Laptop", "Electronics"));
        searchOps.addProduct(new Product("P002", "Smartphone", "Electronics"));
        searchOps.addProduct(new Product("P003", "Tablet", "Electronics"));
        searchOps.addProduct(new Product("P004", "Headphones", "Accessories"));

        // Display all products
        System.out.println("All products:");
        searchOps.displayProducts();

        // Searching for products using linear search
        System.out.println("\nLinear Search:");
        Product foundProductLinear = searchOps.linearSearch("Tablet");
        if (foundProductLinear != null)
        {
            System.out.println("Product found: " + foundProductLinear);
        }
        else
        {
            System.out.println("Product not found.");
        }

        // Searching for products using binary search
        System.out.println("\nBinary Search:");
        Product foundProductBinary = searchOps.binarySearch("Smartphone");
        if (foundProductBinary != null)
        {
            System.out.println("Product found: " + foundProductBinary);
        }
        else
        {
            System.out.println("Product not found.");
        }
    }
}