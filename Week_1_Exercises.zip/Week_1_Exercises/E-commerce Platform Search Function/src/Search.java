import java.util.Arrays;
import java.util.Comparator;

public class Search
{
    private Product[] products;
    private int size;

    public Search(int capacity)
    {
        products = new Product[capacity];
        size = 0;
    }

    // Add a product to the array
    public void addProduct(Product product)
    {
        if (size >= products.length)
        {
            System.out.println("Inventory is full");
            return;
        }
        products[size] = product;
        size++;
        Arrays.sort(products, 0, size, Comparator.comparing(Product::getProductName));
    }

    // Linear search method to find a product by title
    public Product linearSearch(String t)
    {
        for (Product product : products)
        {
            if (product != null && product.getProductName().equalsIgnoreCase(t))
            {
                return product;
            }
        }
        return null; // Product not found
    }

    // Binary search method to find a product by title
    public Product binarySearch(String t)
    {
        int l = 0;
        int r = size - 1;

        while (l <= r)
        {
            int mid = (l + r) / 2;
            Product midProduct = products[mid];

            int comp = midProduct.getProductName().compareToIgnoreCase(t);
            if (comp == 0)
            {
                return midProduct; // Product found
            }
            else if (comp < 0)
            {
                l = mid + 1; // Search in the right half
            }
            else
            {
                r = mid - 1; // Search in the left half
            }
        }
        return null; // Product not found
    }

    // Method to display all products
    public void displayProducts()
    {
        for (int i = 0; i < size; i++)
        {
            System.out.println(products[i]);
        }
    }
}