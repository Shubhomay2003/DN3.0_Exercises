public class Logger
{
    // Private static instance of the same class
    private static Logger ob;

    // Private constructor to prevent instantiation from another class
    private Logger()
    {
        // Initialization code, if necessary (I haven't done any initialization)
    }

    // Public method to provide access to the instance
    public static Logger getInstance()
    {
        if (ob == null)
        {
            synchronized (Logger.class)//Ensures that only one thread can execute the block of code inside it at a time
            {
                if (ob == null)
                {
                    ob = new Logger();
                }
            }
        }
        return ob;
    }

    //Method to log a message
    public void log(String m) {
        System.out.println(m);
    }
}