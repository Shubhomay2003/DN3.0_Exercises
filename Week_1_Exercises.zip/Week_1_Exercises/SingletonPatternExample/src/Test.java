public class Test
{
    public static void main(String[] args)
    {
        // Retrieve the single instance of Logger
        Logger l1 = Logger.getInstance();
        Logger l2 = Logger.getInstance();

        // Test if both references point to the same instance
        if (l1 == l2)
        {
            System.out.println("Both references point to the same instance.");
        }
        else
        {
            System.out.println("Different instances detected!");
        }

        // Use the logger to log a message
        l1.log("This is a log message from logger1.");
        l2.log("This is a log message from logger2.");
    }
}
