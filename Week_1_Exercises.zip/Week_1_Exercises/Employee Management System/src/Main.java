
public class Main
{
    public static void main(String[] args)
    {
        EmployeeManagement empManagement = new EmployeeManagement(5);

        // Adding employees
        empManagement.addEmployee(new Employee("E001", "Shubhomay Kundu Poddar", "Manager", 75000));
        empManagement.addEmployee(new Employee("E002", "Aritra Banerjee", "Developer", 60000));
        empManagement.addEmployee(new Employee("E003", "Shubhodip Das", "Designer", 55000));
        empManagement.addEmployee(new Employee("E004", "Shreya Dasgupta", "Developer", 65000));
        empManagement.addEmployee(new Employee("E005", "Sakshi Gupta", "HR", 50000));

        // Traverse and display all employees
        System.out.println("All Employees:");
        empManagement.traverseEmployees();

        // Search for an employee
        System.out.println("\nSearching for Employee E002:");
        Employee foundEmployee = empManagement.searchEmployee("E002");
        if (foundEmployee != null)
        {
            System.out.println("Employee found: " + foundEmployee);
        }
        else
        {
            System.out.println("Employee not found.");
        }

        // Deleting an employee
        System.out.println("\nDeleting Employee E003:");
        empManagement.deleteEmployee("E003");
        System.out.println("Employees after deletion:");
        empManagement.traverseEmployees();

    }
}