// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main
{
    public static void main(String[] args)
    {
        Order[] orders = new Order[5];
        orders[0] = new Order("O001", "Shubhomay", 250.0);
        orders[1] = new Order("O002", "Aritra", 150.0);
        orders[2] = new Order("O003", "Shubhodeep", 305.0);
        orders[3] = new Order("O004", "Shreya", 200.0);
        orders[4] = new Order("O005", "Sakshi", 120.0);

        System.out.println("Unsorted Orders:");
        Sort.displayOrders(orders);

        // Sorting using Bubble Sort
        Sort.bubbleSort(orders);
        System.out.println("\nOrders Sorted by Bubble Sort:");
        Sort.displayOrders(orders);

        // Adding some more orders and reordering
        orders = new Order[5];
        orders[0] = new Order("O001", "Shubhomay", 250.0);
        orders[1] = new Order("O002", "Aritra", 150.0);
        orders[2] = new Order("O003", "Shubhodeep", 305.0);
        orders[3] = new Order("O004", "Shreya", 200.0);
        orders[4] = new Order("O005", "Sakshi", 120.0);

        // Sorting using Quick Sort
        Sort.quickSort(orders, 0, orders.length - 1);
        System.out.println("\nOrders Sorted by Quick Sort:");
        Sort.displayOrders(orders);
    }
}