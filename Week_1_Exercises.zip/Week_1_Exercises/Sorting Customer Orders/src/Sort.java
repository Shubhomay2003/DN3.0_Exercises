public class Sort {

    // Bubble Sort to sort orders by totalPrice
    public static void bubbleSort(Order[] orders)
    {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - 1 - i; j++)
            {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice())
                {
                    // Swap orders[j] and orders[j + 1]
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    // Quick Sort to sort orders by totalPrice
    public static void quickSort(Order[] orders, int low, int high)
    {
        if (low < high)
        {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);  // Recursively sort left subarray
            quickSort(orders, pi + 1, high); // Recursively sort right subarray
        }
    }

    // Partition method used in Quick Sort
    private static int partition(Order[] orders, int low, int high)
    {
        Order pivot = orders[high];
        int i = (low - 1); // Index of smaller element
        for (int j = low; j < high; j++)
        {
            if (orders[j].getTotalPrice() < pivot.getTotalPrice())
            {
                i++;
                // Swap orders[i] and orders[j]
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        // Swap orders[i + 1] and pivot (orders[high])
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    // Method to display the orders
    public static void displayOrders(Order[] orders)
    {
        for (Order order : orders)
        {
            System.out.println(order);
        }
    }
}