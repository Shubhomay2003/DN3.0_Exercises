public class Test
{
    public static void main(String[] args)
    {
        //Here in this example we create all type of document objects as mentioned in assignment
        // Create Word Document
        DocumentFactory wordF = new WordDocumentFactory();
        Document word = wordF.createDocument();
        word.open();
        word.close();

        // Create PDF Document
        DocumentFactory pdfF = new PdfDocumentFactory();
        Document pdf = pdfF.createDocument();
        pdf.open();
        pdf.close();

        // Create Excel Document
        DocumentFactory excelF = new ExcelDocumentFactory();
        Document excel = excelF.createDocument();
        excel.open();
        excel.close();
    }
}
