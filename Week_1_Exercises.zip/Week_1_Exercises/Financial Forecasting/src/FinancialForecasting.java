
public class FinancialForecasting
{

    // Recursive method to calculate future value
    public static double calculateFutureValue(double initialValue, double growthRate, int years)
    {
        // Base case: if no years, return the initial value
        if (years == 0)
        {
            return initialValue;
        }
        // Recursive case: calculate the value for the next year
        return calculateFutureValue(initialValue, growthRate, years - 1) * (1 + growthRate);
    }


    public static void main(String[] args)
    {
        // Initial value, growth rate and number of years
        double initialValue = 10000.0;
        double growthRate = 0.05; // 5% growth rate
        int years = 10;

        // Calculate the future value
        double futureValue = calculateFutureValue(initialValue, growthRate, years);

        // Display the result
        System.out.printf("The value after %d years is: %.2f%n", years, futureValue);
    }
}