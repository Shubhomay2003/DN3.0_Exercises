public class StudentController
{
    private Student stu;
    private StudentView view;

    // Constructor
    public StudentController(Student s, StudentView view)
    {
        this.stu = s;
        this.view = view;
    }

    // Set student name
    public void setStudentName(String name)
    {
        stu.setName(name);
    }

    // Get student name
    public String getStudentName()
    {
        return stu.getName();
    }

    // Set student id
    public void setStudentId(int id)
    {
        stu.setId(id);
    }

    // Get student id
    public int getStudentId()
    {
        return stu.getId();
    }

    // Set student grade
    public void setStudentGrade(String grade)
    {
        stu.setGrade(grade);
    }

    // Get student grade
    public String getStudentGrade()
    {
        return stu.getGrade();
    }

    // Update view
    public void updateView()
    {
        view.displayStudentDetails(stu.getName(), stu.getId(), stu.getGrade());
    }
}