public class Test
{
    public static void main(String[] args)
    {
        // Create the model
        Student student = new Student("Shubhomay Kundu Poddar", 76, "A");

        // Create the view
        StudentView view = new StudentView();

        // Create the controller
        StudentController controller = new StudentController(student, view);

        // Update the view
        controller.updateView();

        // Update the student details
        controller.setStudentName("Shubhomay Kundu Poddar");
        controller.setStudentId(71);
        controller.setStudentGrade("B");

        // Update the view with new details
        controller.updateView();
    }
}