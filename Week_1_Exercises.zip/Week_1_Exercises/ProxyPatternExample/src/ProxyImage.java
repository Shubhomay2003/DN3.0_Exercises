public class ProxyImage implements Image
{
    private RealImage ri;
    private String fname;

    public ProxyImage(String fname) {
        this.fname = fname;
    }

    @Override
    public void display()
    {
        if (ri == null)
        {
            ri = new RealImage(fname);
        }
        ri.display();
    }
}