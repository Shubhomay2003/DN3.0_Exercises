public class RealImage implements Image
{
    private String fname;

    public RealImage(String fname)
    {
        this.fname = fname;
        loadImageFromServer();
    }

    private void loadImageFromServer()
    {
        // Simulate a delay for loading image from a remote server
        System.out.println("Loading image: " + fname);
    }

    @Override
    public void display()
    {
        System.out.println("Displaying image: " + fname);
    }
}