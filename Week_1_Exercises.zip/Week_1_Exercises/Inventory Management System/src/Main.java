
public class Main
{
    public static void main(String[] args)
    {
        InventoryManagementSystem ims = new InventoryManagementSystem();

        // Add products
        ims.addProduct(new Product("P001", "Laptop", 10, 46999.99));
        ims.addProduct(new Product("P002", "Smartphone", 20, 15999.00));
        ims.addProduct(new Product("P003", "Tablet", 15, 25000.00));

        // Display products
        System.out.println("All products:");
        ims.displayProducts();

        // Update a product
        ims.updateProduct("P002", new Product("P002", "Smartphone", 25, 30250.99));

        // Delete a product
        ims.deleteProduct("P003");

        // Display products after update and delete
        System.out.println("\nProducts after update and delete:");
        ims.displayProducts();
    }
}
