import java.util.HashMap;
import java.util.Map;

class InventoryManagementSystem
{
    private Map<String, Product> inventory;

    public InventoryManagementSystem()
    {
        this.inventory = new HashMap<>();
    }

    // Add a product to the inventory
    public void addProduct(Product product)
    {
        inventory.put(product.getProductId(), product);
        System.out.println("Product added: " + product);
    }

    // Update a product in the inventory
    public void updateProduct(String productId, Product updatedProduct)
    {
        if (inventory.containsKey(productId))
        {
            inventory.put(productId, updatedProduct);
            System.out.println("Product updated: " + updatedProduct);
        }
        else
        {
            System.out.println("Product not found: " + productId);
        }
    }

    // Delete a product from the inventory
    public void deleteProduct(String productId)
    {
        Product removedProduct = inventory.remove(productId);
        if (removedProduct != null)
        {
            System.out.println("Product deleted: " + removedProduct);
        }
        else
        {
            System.out.println("Product not found: " + productId);
        }
    }

    // Display all products in the inventory
    public void displayProducts()
    {
        for (Product product : inventory.values())
        {
            System.out.println(product);
        }
    }
}
