class Node
{
    Task data;
    Node next;

    Node(Task data)
    {
        this.data = data;
        this.next = null;
    }
}

public class TaskManagement
{
    private Node head;

    public TaskManagement()
    {
        this.head = null;
    }

    // Add task to the end of the list
    public void addTask(Task task)
    {
        Node newNode = new Node(task);
        if (head == null)
        {
            head = newNode;
        }
        else
        {
            Node temp = head;
            while (temp.next != null)
            {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Search for a task by taskId
    public Task searchTask(String taskId)
    {
        Node temp = head;
        while (temp != null)
        {
            if (temp.data.getTaskId().equals(taskId))
            {
                return temp.data;
            }
            temp = temp.next;
        }
        return null; // Task not found
    }

    // Traverse and display all tasks
    public void traverseTasks()
    {
        Node temp = head;
        while (temp != null)
        {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }

    // Delete a task by taskId
    public void deleteTask(String taskId)
    {
        if (head == null) return;

        if (head.data.getTaskId().equals(taskId))
        {
            head = head.next;
            return;
        }

        Node current = head;
        while (current.next != null && !current.next.data.getTaskId().equals(taskId))
        {
            current = current.next;
        }

        if (current.next != null)
        {
            current.next = current.next.next;
        }
    }
}