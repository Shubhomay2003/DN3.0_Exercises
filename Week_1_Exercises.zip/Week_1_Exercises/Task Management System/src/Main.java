
public class Main
{
    public static void main(String[] args)
    {
        TaskManagement taskList = new TaskManagement();

        // Adding tasks
        taskList.addTask(new Task("T001", "Design database schema", "In Progress"));
        taskList.addTask(new Task("T002", "Develop login module", "Pending"));
        taskList.addTask(new Task("T003", "Implement search functionality", "Completed"));
        taskList.addTask(new Task("T004", "Create user dashboard", "In Progress"));

        // Traverse and display all tasks
        System.out.println("All Tasks:");
        taskList.traverseTasks();

        // Search for a task
        System.out.println("\nSearching for Task T002:");
        Task foundTask = taskList.searchTask("T002");
        if (foundTask != null)
        {
            System.out.println("Task found: " + foundTask);
        }
        else
        {
            System.out.println("Task not found.");
        }

        // Deleting a task
        System.out.println("\nDeleting Task T003:");
        taskList.deleteTask("T003");
        System.out.println("Tasks after deletion:");
        taskList.traverseTasks();
    }
}