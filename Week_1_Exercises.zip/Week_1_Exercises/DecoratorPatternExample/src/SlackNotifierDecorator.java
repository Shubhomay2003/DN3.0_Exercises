public class SlackNotifierDecorator extends NotifierDecorator
{
    public SlackNotifierDecorator(Notifier w)
    {
        super(w);
    }

    @Override
    public void send(String m)
    {
        super.send(m); // Delegate to the wrapped Notifier
        System.out.println("Sending Slack notification with message: " + m);
    }
}
