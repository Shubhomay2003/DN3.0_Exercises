public abstract class NotifierDecorator implements Notifier
{
    protected Notifier w;

    public NotifierDecorator(Notifier w)
    {
        this.w = w;
    }

    @Override
    public void send(String m)
    {
        w.send(m);
    }
}