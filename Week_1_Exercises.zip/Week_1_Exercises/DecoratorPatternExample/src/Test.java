public class Test
{
    public static void main(String[] args)
    {
        // Create a basic EmailNotifier
        Notifier emailNotifier = new EmailNotifier();

        // Wrap the EmailNotifier with SMSNotifierDecorator
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);

        // Further wrap the SMSNotifier with SlackNotifierDecorator
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        // Sending notification using the final decorated notifier
        slackNotifier.send("Hello World!");
    }
}