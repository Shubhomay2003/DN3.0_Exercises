public class SMSNotifierDecorator extends NotifierDecorator
{
    public SMSNotifierDecorator(Notifier w)
    {
        super(w);
    }

    @Override
    public void send(String m)
    {
        super.send(m); // Delegate to the wrapped Notifier
        System.out.println("Sending SMS with message: " + m);
    }
}