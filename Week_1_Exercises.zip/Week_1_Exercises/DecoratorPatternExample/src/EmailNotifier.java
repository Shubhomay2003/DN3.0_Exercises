public class EmailNotifier implements Notifier
{
    @Override
    public void send(String m)
    {
        System.out.println("Sending Email with message: " + m);
    }
}