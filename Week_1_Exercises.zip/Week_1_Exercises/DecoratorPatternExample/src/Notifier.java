public interface Notifier
{
    void send(String m);
}