package com.code.employee.projection;

public interface Employeeprojection {

	String getName();
	String getSalary();
}
